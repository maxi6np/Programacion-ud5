package ArraysBidimensionales.ExamenInmobiliaria;

public enum Estadisticas {
    MAX_HABITACIONES, MAX_ASEOS, MAX_SUPERFICIE
}
