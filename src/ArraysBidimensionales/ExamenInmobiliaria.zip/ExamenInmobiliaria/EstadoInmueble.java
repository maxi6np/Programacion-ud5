package ArraysBidimensionales.ExamenInmobiliaria;

import ArraysBidimensionales.Ejer5x13.ColorSemaforo;

public enum EstadoInmueble {
    SE_VENDE,
    VENDIDO,
    SE_ALQUILA,
    ALQUILADO;
}
